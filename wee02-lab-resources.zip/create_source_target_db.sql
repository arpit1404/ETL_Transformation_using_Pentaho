DROP SCHEMA IF EXISTS source_db;
CREATE SCHEMA source_db;

DROP SCHEMA IF EXISTS target_db;
CREATE SCHEMA target_db;

DROP TABLE IF EXISTS source_db.revenue;
CREATE TABLE source_db.revenue
(
  DATE DATE,
  country_iso_code VARCHAR(3),
  revenue DECIMAL
);

INSERT INTO source_db.revenue
VALUES
      ('2011-11-01','GB',22314),
      ('2011-11-02','GB',23411),
      ('2011-11-03','GB',22325),
      ('2011-11-04','GB',22233),
      ('2011-11-01','US',32423),
      ('2011-11-02','US',25325),
      ('2011-11-03','US',43523),
      ('2011-11-04','US',23453)
;

DROP TABLE IF EXISTS source_db.countries;
CREATE TABLE source_db.countries
(
  country_iso_code VARCHAR(3),
  country_name VARCHAR(100)
);


INSERT INTO source_db.countries
VALUES
        ('GB','United Kingdom'),
        ('US','United States of America')
;

DROP TABLE IF EXISTS target_db.customer;
CREATE TABLE target_db.customer (
  account_num BIGINT(20) DEFAULT NULL,
  lname VARCHAR(18) DEFAULT NULL,
  fname VARCHAR(18) DEFAULT NULL,
  mi VARCHAR(8) DEFAULT NULL,
  address1 VARCHAR(27) DEFAULT NULL,
  address2 VARCHAR(12) DEFAULT NULL,
  address3 DATETIME DEFAULT NULL,
  address4 DATETIME DEFAULT NULL,
  city VARCHAR(14) DEFAULT NULL,
  state_province VARCHAR(9) DEFAULT NULL,
  postal_code BIGINT(20) DEFAULT NULL,
  country VARCHAR(6) DEFAULT NULL,
  customer_region_id BIGINT(20) DEFAULT NULL,
  phone1 VARCHAR(13) DEFAULT NULL,
  phone2 VARCHAR(13) DEFAULT NULL,
  birthdate DATETIME DEFAULT NULL,
  marital_status CHAR(1) DEFAULT NULL,
  yearly_income VARCHAR(13) DEFAULT NULL,
  gender CHAR(1) DEFAULT NULL,
  total_children BIGINT(20) DEFAULT NULL,
  num_children_at_home BIGINT(20) DEFAULT NULL,
  education VARCHAR(19) DEFAULT NULL,
  date_accnt_opened DATETIME DEFAULT NULL,
  member_card VARCHAR(6) DEFAULT NULL,
  occupation VARCHAR(14) DEFAULT NULL,
  houseowner TINYINT(1) DEFAULT NULL,
  num_cars_owned BIGINT(20) DEFAULT NULL,
  fullname VARCHAR(26) DEFAULT NULL
);

DROP TABLE IF EXISTS target_db.src_time;
CREATE TABLE target_db.src_time
(
    the_date TINYTEXT
  , the_day TINYTEXT
  , the_month TINYTEXT
  , the_year INT
  , day_of_month INT
  , week_of_year INT
  , month_of_year INT
  , quarter TINYTEXT
  , fiscal_period TINYTEXT
);

DROP TABLE IF EXISTS target_db.city_state;
CREATE TABLE target_db.city_state
(
  city VARCHAR(14)
, state_province VARCHAR(9)
);